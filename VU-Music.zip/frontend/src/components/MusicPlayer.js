import React, { useState } from 'react';

const MusicPlayer = ({ trackUrl }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audio = new Audio(trackUrl);

  const togglePlay = () => {
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="music-player">
      <button onClick={togglePlay}>
        {isPlaying ? "Pause" : "Play"}
      </button>
    </div>
  );
};

export default MusicPlayer;
