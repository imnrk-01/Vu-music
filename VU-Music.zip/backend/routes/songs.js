const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const songs = [
    { id: 1, name: "Copyright-Free Song 1" },
    { id: 2, name: "Copyright-Free Song 2" },
  ];
  res.json(songs);
});

module.exports = router;
